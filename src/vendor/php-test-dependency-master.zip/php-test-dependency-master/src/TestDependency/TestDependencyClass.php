<?php

namespace RetroSoft\TestDependency;

class TestDependencyClass {

	public function __construct() {
		echo "TestDependencyClass constructor called\n";
	}

	public function testMethod() {
		echo "TestDependencyClass testMethod() called\n";
	}

	public static function testStaticMethod() {
		echo "TestDependencyClass testStaticMethod() called\n";
	}

}
